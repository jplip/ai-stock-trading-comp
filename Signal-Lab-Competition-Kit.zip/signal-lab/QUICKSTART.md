# Signal Lab

A working stock-model experiment kit for your AI Club competition. The browser version needs no Python, account, API key, or installation.

## Start here

1. Open **Signal-Lab.html** from the competition ZIP in your browser. You can also open `signal-lab/dist/index.html` with its neighboring files intact.
2. The app trains three models on **synthetic demo prices** and shows their results. Those prices are generated, not real stock history.
3. Open **Model notes** to learn what the models use and how to explain the project.
4. Once the club supplies data, choose **Upload CSV**, then run the experiment. Use **Data & rules** for the expected columns and timing.
5. Export predictions, the latest proposed allocation, or the experiment report when needed. These are generic files; their format may need changing for the club's simulator.

## What you built

The app extracts nine facts from a stock's recent history, such as recent returns, price variation, the opening gap, and relative trading volume. It trains three different models:

- **Logistic regression:** learns a weighted combination of the inputs.
- **Random forest:** combines 17 small decision trees learned from resampled historical examples.
- **Nearest neighbors:** looks for similar past observations and combines their outcomes.

The models produce scores for whether a future open-to-open return will be positive. Their ensemble weights are chosen using an earlier validation period. A trading rule turns the combined score into a proposed fraction of capital invested in the stock, with the rest in cash. These scores are **uncalibrated**; a score of 0.60 is not a verified 60% chance of a profitable trade.

## The timing matters

At the close of day **t**, the model uses information available through that close. The simulated trade fills at the open of **t+1**, then earns the return from that open to the open of **t+2**. The model is not trying to predict the overnight return from today's close to tomorrow's open.

The default chronological split is roughly 60% training, 20% validation, and 20% final testing after the initial feature lookback. Two observations are purged at each split boundary. During testing, the browser models retrain every 20 observations using only labels whose outcomes occurred before the prediction date. The ensemble weights remain fixed from validation. The report includes fit dates that can be inspected.

The simulator charges costs when allocation changes and when the final position is sold. It tracks how the stock's changing price alters the invested fraction between rebalances. Buying and holding is evaluated over the same period with entry and exit costs too. Cash earns zero. There is one stock, no borrowing, and no short selling. Partial allocations are allowed. Costs use a simplified allocation-notional calculation. The engine does not simulate individual limit orders, taxes, liquidity, or market impact.

## CSV data

Required columns: `Date,Open,Close`.

Recommended columns: `Date,Open,High,Low,Close,Volume`.

Use one stock, one daily row per date, and 180–5,000 rows. Dates can be `YYYY-MM-DD` or US-style `M/D/YYYY`. Column names are case insensitive. Rows can arrive in reverse order; the import sorts them and reports that change. Duplicated dates, invalid prices, and multiple tickers are rejected.

If high/low or volume are absent, the app reports its substitutions. Use consistently split-adjusted OHLC prices when available: mixing adjusted closes with unadjusted opens can create false returns. Inspect the source data for splits and other discontinuities. Sharpe and volatility calculations assume 252 observations per year and a zero risk-free rate. The app does not fetch live prices. CSV contents are processed within the browser.

## Before the official competition run

Find out what the organizers require: which data you may use, what period is predicted, which trading actions are allowed, how they score results, and what file or function they accept. Those rules are not in the flyer, so this kit is **not connected to the official simulator yet**.

Adjusting settings after looking at final-test results uses that period for development. Reserve another unseen period, or use the organizer's hidden test, for an honest final evaluation. A good synthetic result does not establish real-market performance or guarantee a competition win.

## Code and optional Python version

The full browser model is in `dist/engine.js`. The interface is `dist/app.js`, with `dist/index.html` and `dist/style.css`. The engine exports `generateDemo`, `parseCSV`, and `runExperiment` and can also be required in Node.js. It uses custom educational implementations rather than external ML libraries.

The optional `python/` folder contains a separate NumPy-based ensemble for adapting to a Python competition environment. Its validation weighting, allocation rule, and test refit policy differ from the browser version; see its README. It is not expected to reproduce browser results. You can use the entire browser app without installing it.

For the engine's checks, run `node tests/engine.test.cjs` and `node tests/integration.test.cjs` from the `signal-lab` folder.

## Background references

- [Time-ordered validation](https://scikit-learn.org/stable/modules/generated/sklearn.model_selection.TimeSeriesSplit.html)
- [Preventing data leakage](https://scikit-learn.org/stable/common_pitfalls.html#data-leakage)
- [Random forests and other ensembles](https://scikit-learn.org/stable/modules/ensemble.html#forest)

These references explain the underlying concepts; this app implements its own models and chronological evaluation rather than calling scikit-learn.
